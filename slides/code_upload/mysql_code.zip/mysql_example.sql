-- 1. 数据库操作
-- 1.1 创建数据库
-- if not exists表示如果不存在则创建
CREATE SCHEMA IF NOT EXISTS `bda` DEFAULT CHARACTER SET UTF8;
-- 1.2.1 查询所有数据库 
SHOW DATABASES;
-- 1.2.2 查询名为bda的数据库
SHOW DATABASES LIKE 'bda';
-- 1.2.3 将数据库bda作为当前的默认数据库
USE `bda`;
-- 1.2.4 查询当前的数据库
SELECT DATABASE();
-- 1.3 删除数据库bda 
-- drop database `bda`;

-- 2. 数据库表操作
-- 2.1 创建表
CREATE TABLE `bda`.`stu` (
  `stu_id` INT NOT NULL,
  `stu_name` VARCHAR(45) NULL,
  `birth_year` INT NULL,
  `birth_place` VARCHAR(45) NULL,
  PRIMARY KEY (`stu_id`));
CREATE TABLE `bda`.`course` (
  `course_id` INT NOT NULL,
  `course_name` VARCHAR(45) NULL,
  PRIMARY KEY (`course_id`));
CREATE TABLE `bda`.`enroll` (
  `stu_id` INT NOT NULL,
  `course_id` INT NOT NULL,
  `grade` INT NULL,
  PRIMARY KEY (`stu_id`, `course_id`),
  INDEX `course_id_idx` (`course_id` ASC) VISIBLE,
  CONSTRAINT `stu_id`
    FOREIGN KEY (`stu_id`)
    REFERENCES `bda`.`stu` (`stu_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `course_id`
    FOREIGN KEY (`course_id`)
    REFERENCES `bda`.`course` (`course_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
-- 2.2 插入数据
-- 2.2.1 insert .. values
INSERT INTO `course` VALUES (1001,'大数据分析基础');
INSERT INTO `course` (course_name,course_id) VALUES ('大数据商务分析',1002);
INSERT INTO `course` SET course_id = 2001, course_name = '物流仿真';
INSERT INTO `course` VALUES (1003,'数据挖掘'),(1004,'统计分析'),(2002,'运营管理'),(2003,'工程伦理'),(3001,'论文写作');
-- 2.2.2 从文件导入数据
-- 注意可能需要事先设置my.ini文件中的secure-file-priv
-- 通过show variables like '%secure%';查看secure_file_priv的值，如果不为空或者文件所在路径则需要修改my.ini
-- 该文件的位置可以通过 show variables like '%datadir%'; 查看
-- 找到secure_file_priv，将其改为secure_file_priv=''
-- 保存文件，然后重启mysql服务
-- 下面这条语句是为了确保可以使用local关键词
SET GLOBAL local_infile=1;
-- 查看local_infile的值，为ON则可以
SHOW VARIABLES LIKE '%local%';
LOAD DATA LOCAL INFILE 'C:/Users/binfang/Documents/teaching/Code/student.csv' INTO TABLE `stu` FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n' IGNORE 1 LINES;
LOAD DATA LOCAL INFILE 'C:/Users/binfang/Documents/teaching/Code/enroll.csv' INTO TABLE `enroll` FIELDS TERMINATED BY ',' IGNORE 1 LINES;

-- 2.3 查询
-- 2.3.1 单个表查询
-- 查询所有学生的姓名
SELECT stu_name FROM `stu`;
-- 查询学生的姓名、出生年份、出生地，列的顺序可以和表本身不一致
SELECT stu_name,birth_place,birth_year FROM `stu`;
-- 查询学生的所有信息
SELECT * FROM `stu`;
-- 给返回的结果起个别名
SELECT stu_name AS 学生姓名, birth_place AS 出生地, birth_year AS 出生年份 FROM `stu`;
-- 对返回的结果进行简单的计算
SELECT stu_name AS 学生姓名, birth_place AS 出生地, 2019-birth_year AS 年龄 FROM `stu`;
-- 使用YEAR(CURDATE())来获取当前的年份
SELECT stu_name AS 学生姓名, birth_place AS 出生地, YEAR(CURDATE())-birth_year AS 年龄 FROM `stu`;
-- 从enroll表中选出所有已经选课的学生的学号
SELECT stu_id from `enroll`;
-- 去掉重复的结果
SELECT DISTINCT stu_id from `enroll`;
-- 增加一个条件：1985年以后出生
SELECT stu_name AS 学生姓名 FROM `stu` WHERE birth_year>1985;
-- 非1985年以后出生
SELECT stu_name AS 学生姓名 FROM `stu` WHERE NOT birth_year>1985;
-- 1985年以后或者1975年以前出生
SELECT stu_name AS 学生姓名 FROM `stu` WHERE birth_year>1985 OR birth_year<1975;
-- 1990或者1985出生
SELECT * FROM stu WHERE birth_year=1990 OR birth_year = 1985;
SELECT stu_name AS 学生姓名 FROM `stu` WHERE birth_year in (1990,1985);
-- 不在1985-1990这几年出生
SELECT stu_name AS 学生姓名 FROM `stu` WHERE birth_year not between 1985 and 1990;
-- 姓杨的学生
SELECT stu_name AS 学生姓名 FROM `stu` WHERE stu_name LIKE '杨%';
-- 姓杨、单名的学生
SELECT stu_name AS 学生姓名 FROM `stu` WHERE stu_name LIKE '杨_';
-- 姓名中带有‘山’的学生
SELECT stu_name AS 学生姓名 FROM `stu` WHERE stu_name LIKE '%山%';
-- 根据出生地分组，并计算每个地方的人数和最小年龄
SELECT birth_place, COUNT(*) AS 人数, MIN(2019-birth_year) AS 最小年龄 FROM `stu` GROUP BY birth_place;
-- 筛选出人数大于2的记录
SELECT birth_place, COUNT(*) AS 人数, MIN(2019-birth_year) AS 最小年龄 FROM `stu` GROUP BY birth_place HAVING COUNT(*)>2;
-- 根据最小年龄和人数排序，默认为升序
SELECT birth_place, COUNT(*) AS 人数, MIN(2019-birth_year) AS 最小年龄 FROM `stu` GROUP BY birth_place HAVING COUNT(*)>1 ORDER BY 最小年龄,人数 ASC;
-- 只显示从1开始的3条
SELECT birth_place, COUNT(*) AS 人数, MIN(2019-birth_year) AS 最小年龄 FROM `stu` GROUP BY birth_place HAVING COUNT(*)>1 ORDER BY 最小年龄,人数 ASC LIMIT 1,3;

-- 使用UNION对两个查询结果进行合并
SELECT * FROM `stu` WHERE birth_year=1990 UNION SELECT * FROM `stu` WHERE birth_year = 1970;

-- 3.3.2. 连接
-- 创建一个新的生肖表
CREATE TABLE `bda`.`zodiac` (
  `zodiac_year` INT NOT NULL,
  `zodiac_name` VARCHAR(45) NULL,
  PRIMARY KEY (`zodiac_year`));
LOAD DATA LOCAL INFILE 'C:/Users/binfang/Documents/teaching/Code/zodiac.csv' INTO TABLE `zodiac` FIELDS TERMINATED BY ',' IGNORE 1 LINES;

-- 左外连接
SELECT * FROM `stu` LEFT JOIN `zodiac` ON `stu`.birth_year = `zodiac`.zodiac_year;
-- 右外连接
SELECT * FROM `stu` RIGHT JOIN `zodiac` ON `stu`.birth_year = `zodiac`.zodiac_year;
-- 内连接
SELECT * FROM `stu` INNER JOIN `zodiac` ON `stu`.birth_year = `zodiac`.zodiac_year;
-- 交叉连接
SELECT * FROM `stu` CROSS JOIN `zodiac` WHERE `stu`.birth_place LIKE '江西';
SELECT * FROM `stu`,`zodiac` WHERE `stu`.birth_place LIKE '江西';

-- 三张表连接
SELECT `stu`.stu_name,`course`.course_name,grade FROM `enroll`,`stu`,`course` WHERE `course`.course_id = `enroll`.course_id AND `stu`.stu_id = `enroll`.stu_id AND `stu`.stu_id=356201901;
SELECT `stu`.stu_name,`course`.course_name,grade FROM `enroll`,`stu`,`course` WHERE `course`.course_id = `enroll`.course_id AND `stu`.stu_id = `enroll`.stu_id AND `stu`.stu_id IN (SELECT stu_id FROM `stu` WHERE stu_name LIKE '杨%');

-- 2.3.3. 嵌套查询
-- 2.3.3.1. 返回单个值的子查询
-- 查找与杨过出生地相同的学生的姓名
SELECT stu_name FROM `stu` WHERE birth_place = (SELECT birth_place FROM `stu` WHERE stu_name = '杨过') AND stu_name <> '杨过';
-- 列出所有出生地相同的学生对（自己和自己除外）
SELECT A.stu_name,B.stu_name FROM `stu` A,`stu` B WHERE A.birth_place = B.birth_place AND A.stu_name <> B.stu_name;
-- 2.3.3.2. 返回一组值的子查询
-- 比子查询的任意一个值小就可以
SELECT * FROM `stu` WHERE birth_year < ANY (SELECT birth_year FROM `stu` WHERE birth_place = '江西');
-- 比子查询的平均值小就可以
SELECT * FROM `stu` WHERE birth_year < (SELECT AVG(birth_year) FROM `stu` WHERE birth_place = '江西');
-- 比子查询的所有值小
SELECT * FROM `stu` WHERE birth_year < ALL (SELECT MAX(birth_year) FROM `stu` WHERE birth_place = '江西');
-- 2.3.3.3. exists子查询
-- 是否存在以大数据开头的课程，有则列出所有学生的姓名，无则返回空集
-- 本例仅作演示用处，结果没有实际意义
SELECT stu_name FROM `stu` WHERE EXISTS (SELECT * FROM `course` WHERE course_name LIKE '大数据%');

-- 2.4. 更新数据
-- 黄药师的出生年份修改为1977
UPDATE `stu` SET birth_year = 1977 WHERE stu_name = '黄药师';
-- 所有人的出生年份加1
UPDATE `stu` SET birth_year = birth_year + 1;

-- 2.5. 删除数据
-- 删除陈家洛(enroll表中相应的数据也会被删除)
DELETE FROM `stu` WHERE stu_name = '陈家洛';

-- 2.6. 视图
-- 创建视图
CREATE VIEW stu_90 AS (SELECT stu_id,stu_name,birth_year FROM `stu` WHERE birth_year > 1990);
-- 查询视图
SELECT * FROM `stu_90`;

-- 2.7. 创建索引
-- 新建一张大型的学生信息表
-- 其中主键设置为自增长
CREATE TABLE `bda`.`stu_big` (
  `id` BIGINT(30) NOT NULL AUTO_INCREMENT,
  `stu_id` INT NULL,
  `stu_name` VARCHAR(45) NULL,
  `birth_year` INT NULL,
  `birth_place` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));
LOAD DATA LOCAL INFILE 'C:/Users/binfang/Documents/teaching/Code/student_large.csv' INTO TABLE `stu_big` FIELDS TERMINATED BY ',' IGNORE 0 LINES (stu_id, stu_name, birth_year, birth_place);
-- 在大表中耗时0.1s
SELECT COUNT(*) FROM `stu_big` WHERE birth_year=1990;
-- 在小表中耗时0.01s
SELECT COUNT(*) FROM `stu` WHERE birth_year=1990;
-- 针对birth_year创建一个索引
CREATE INDEX year_index ON `stu_big` (birth_year);
-- 再次运行上述语句，耗时0.0s